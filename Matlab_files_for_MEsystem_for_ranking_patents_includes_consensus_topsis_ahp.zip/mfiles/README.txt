Matlab files for multi-expert system for ranking patents. Two tier process is applied.
First consensual fuzzy pay-off distributions are determined starting from individual distributions.
Possibilistic moments are calculated from consensus pay-off distributions of each patent and then
used in ranking them with TOPSIS. In tier two, AHP is used to include additional decision variables into
the patent selection. For more information see paper:

[1.] M. Collan, M. Fedrizzi, P. Luukka, A multi-expert system for ranking patents: An approach based on 
fuzzy pay-off distributions and a TOPSIS-AHP framework, Expert Systems with Applications, 40 (2013), 
pp. 4749-4759.


Usage: To first get larger set of rankings based on TOPSIS rankings of possibilistic moments of consensual 
fuzzy pay-offs see mainfile.m in folder Tier1. This ranking is used to select six candidates to 
Tier2 where strategic criterias are used to evaluate candidates by AHP. See also mainfile.m in Tier2 folder.







