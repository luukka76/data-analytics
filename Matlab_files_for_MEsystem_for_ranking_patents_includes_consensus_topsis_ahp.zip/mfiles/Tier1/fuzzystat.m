function [MeanF,VarF,SkewnessF]=fuzzystat(A)
% Calculation of possibilistic mean, variance and skewness.
% function call [MeanF,VarF,SkewnessF]=fuzzystat(A)
% Input: fuzzy number in form A=(l,m,r)
% Output: Mean, variance and skewness of A.
% Mean(A)=m+(r-l)/6;
% Variance(A)=(l+r)^2/24;
% Skewness(A)=(l+r)^2(r-l)/32;
MeanF=A(:,2)+(A(:,3)-A(:,1))/6;
VarF=(A(:,1)+A(:,3)).^2/24;
SkewnessF=(A(:,1)+A(:,3)).^2/32.*(A(:,3)-A(:,1));
