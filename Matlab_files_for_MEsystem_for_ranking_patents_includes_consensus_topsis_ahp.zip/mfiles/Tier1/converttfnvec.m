function Amod=convertfn(A)
%a fuzzy number of form A=(a,b,c) where a<b<c is converted to
%fuzzy number of form A=(l,m,r) where l=b-a, m=b, r=c-b.
[m,n]=size(A);
Amod=[];
for i=1:m
    Amod=[Amod; A(i,2)-A(i,1),A(i,2),A(i,3)-A(i,2)];
end