function [c,DPIS,DNIS]=topsis(data)
% function call: [c,DPIS,DNIS]=topsis(data)
% Input: data matrix of size m x n where we have
% m attributes and n criterions.
% Output:
% c:    Closeness coefficient
% DPIS: Distance to positive ideal solution
% DNIS: Distance to negative ideal solution

x=data;
[m,n]=size(x);  
a=zeros(m,n);
%Initialization:
decisionm=zeros(n,1);

for j=1:n
    for i=1:m
        decisionm(j)=decisionm(j)+x(i,j)^2;
    end
end
%Normalized decision matrix:
for i=1:m
    for j=1:n
        a(i,j)=x(i,j)/sqrt(decisionm(j));
    end
end
%Positive and negative ideal solutions:
PIS=zeros(1,n);
NIS=zeros(1,n);
for j=1:n
    PIS(j)=max(a(:,j));
    NIS(j)=min(a(:,j));
end
%Computing distances to PIS and NIS:
 DPIS=zeros(1,m);
 DNIS=zeros(1,m);
 for i=1:m
     for j=1:n
         DPIS(i)=(PIS(j)-a(i,j))^2+DPIS(i);
         DNIS(i)=(NIS(j)-a(i,j))^2+DNIS(i);
     end
 end
 for i=1:m
     DPIS(i)=sqrt(DPIS(i));
     DNIS(i)=sqrt(DNIS(i));
 end
%Closeness coefficient: 
 c=zeros(1,m);
 for i=1:m
     c(i)=DNIS(i)/(DPIS(i)+DNIS(i));
 end
 c;