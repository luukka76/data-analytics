function Pnew=consensusiteration(P,B,Pii,alpha,beta)

%Distance calculation:
dist=distLR(P,B);
%dissensus:
%cost for changing initial preference:
dist2=distLR(P,Pii);
%Global cost:
lambda=0.0;
%New preference:
gamma=0.005;

%Calculating gradients:

deltaP=P(2)+1/4*(P(3)-P(1));
deltaB=B(2)+1/4*(B(3)-B(1));
deltaPii=Pii(2)+1/4*(Pii(3)-Pii(1));

vi=inertiaCd(dist,alpha,beta);
ui=inertiaCd(dist2,alpha,beta);

deltaWP=((1-lambda)*vi+lambda*ui)*deltaP-(1-lambda)*vi*deltaB-lambda*ui*deltaPii;

deltaPl=1/6*P(1)-1/4*P(2);
deltaBl=1/6*B(1)-1/4*B(2);
deltaPiil=1/6*Pii(1)-1/4*Pii(2);

deltaWl=((1-lambda)*vi+lambda*ui)*deltaPl-(1-lambda)*vi*deltaBl-lambda*ui*deltaPiil;

deltaPr=1/6*P(3)+1/4*P(2);
deltaBr=1/6*B(3)+1/4*B(2);
deltaPiir=1/6*Pii(3)+1/4*Pii(2);

deltaWr=((1-lambda)*vi+lambda*ui)*deltaPr-(1-lambda)*vi*deltaBr-lambda*ui*deltaPiir;

Pnew=P-gamma*[deltaWl,deltaWP,deltaWr];



