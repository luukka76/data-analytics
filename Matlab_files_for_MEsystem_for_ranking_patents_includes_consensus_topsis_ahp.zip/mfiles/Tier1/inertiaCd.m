function fd=inertia(dist,alpha,beta)
%Sigmoidal function f': [0,1]->(0,1)
fd=1/(1+exp(beta*(dist-alpha)));
