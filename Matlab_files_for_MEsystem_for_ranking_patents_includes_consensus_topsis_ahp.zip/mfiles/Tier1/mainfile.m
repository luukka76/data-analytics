
clear all
close all

%Step 1: each expert creates cash-flow scenarios for each investment
%alternative: maximum possible, minimum possible and best estimate
%scenarios:
%Loading the data for this step:

 data1=dlmread('data1.txt');

%Scaling is needed in order for consensus to work properly. 
data1=dataconvert(data1);   %Scaling the data between [0,1]

%Step 2: From each experts' scenarios an individual fuzzy value
%distribution function (pay-off distribution) is created.
%This would be a fuzzy triangular number given allready in the data file.

%Next we change the fuzzy number in form A=(l,m,r)
%In short a fuzzy number of form A=(a,b,c) where a<b<c is converted to
%fuzzy number of form A=(l,m,r) where l=b-a, m=b, r=c-b.
%This is needed for consensus computations.
DMS=4;
j=1;
data=[];
for i=1:DMS    
    DM=converttfnvec(data1(:,j:j+2));
    data=[data DM];
    j=j+3;
end
 
 %3D matrix including all DMs:
j=1;
for i=1:DMS
    data2(:,:,i)=data(:,j:j+2);
    j=j+3;
end

%In data2 information is now in form: data2(patent,fuzzy number,decision maker)
%Initialization of consensus computations:
alpha=0.3;
beta=10;
N=20;
%iter=300;
iter=30000;
%Calculating consensus:
consensus2=Calconsensus(data2,alpha,beta,N,iter,DMS);

%Step 4: Values of possibilistic moments are calculated for each patent
%from the consensus pay-off distributions. These include the possibilistic
%mean, the possibilistic standard deviation, and skewness of the pay-off
%distribution.

%Calculated now for all decision makers consensus fuzzy numbers, but can be
%done also so that one calculates it for i.e. first decision maker 
%(since if consensus is reached these are the same for all decision makers).
%Calculated for all just for checking purposes.

for k=1:N
    for i=1:DMS
        [MeanF(k,i),VarF(k,i),SkewnessF(k,i)]=fuzzystat(consensus2(k,:,i));
    end
end

%Step 5: Calculated possibilistic moments are used in a ranking of the
%patents with TOPSIS

for i=1:DMS
    datastat=[MeanF(:,i) VarF(:,i) SkewnessF(:,i)];
    [c(i,:),DPIS(i,:),DNIS(i,:)]=topsis(datastat);
end
%Rankings:
for i=1:DMS
    [Y(i,:),I(i,:)]=sort(c(i,:),'descend');
end
%Order of the attributes (patents in the example):
disp('Order of the attributes:')
Order=I(1,:)'
Patents=[1:N]';
disp('To check that all four consensus are giving the same ranking')
%If not, then increase iterations or fix other parameters.
Orders=[Patents];
for i=1:DMS
    Orders=[Orders I(i,:)'];
end
Orders

