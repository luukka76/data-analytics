function Pav=Paver(Pall,n,alpha,beta)
%interaction coefficients calculated using inertia for distances:
for i=1:n
    for j=1:n
        vij(i,j)=inertiaCd(distLR(Pall(i,:),Pall(j,:)),alpha,beta);
    end
end
% Effect of interaction coefficient to preferences:
for i=1:n
    rbar(i)=vij(i,[1:i-1 i+1:n])*Pall([1:i-1 i+1:n],2)/sum(vij(i,[1:i-1 i+1:n]));
    el(i)=vij(i,[1:i-1 i+1:n])*Pall([1:i-1 i+1:n],1)/sum(vij(i,[1:i-1 i+1:n]));
    er(i)=vij(i,[1:i-1 i+1:n])*Pall([1:i-1 i+1:n],3)/sum(vij(i,[1:i-1 i+1:n]));
end
Pav=[el' rbar' er']; 