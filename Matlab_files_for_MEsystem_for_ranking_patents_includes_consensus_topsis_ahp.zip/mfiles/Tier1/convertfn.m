function Amod=convertfn(A)
Amod=[A(1)-A(3),A(1),A(2),A(2)+A(4)];
