function consensus=Calcconsensus(data,alpha,beta,N,iter,DMS)

for k=1:N   %over attributes
    Pall=[];
    for j=1:DMS
        Pall=[Pall; data(k,:,j)];
    end
    n=size(Pall,1);
    %For initializations:
    Pav=Paver(Pall,n,alpha,beta);   %Interaction coefficients effect to opinions.
    P=Pall;         %Decision makers opinions on iteration n
    Pold=Pall;      %Decision makers opinions on iteration n-1
    Pave=Pav;       %Interaction coefficients effect to opinions.
    for i=1:iter
         for j=1:n
            Pnew(j,:)=consensusiteration(P(j,:),Pave(j,:),Pold(j,:),alpha,beta);   %one consensus iteration
            Pold(j,:)=P(j,:);
            P(j,:)=Pnew(j,:);
         end
            Pave=Paver(P,n,alpha,beta); %Interaction coefficient effect for next iteration.
    end
    Pconsensus=Pnew;
    %over decision makers:
    for i=1:DMS
        DMconsensusall(k,:,i)=Pconsensus(i,:);
    end
end
consensus=DMconsensusall;

