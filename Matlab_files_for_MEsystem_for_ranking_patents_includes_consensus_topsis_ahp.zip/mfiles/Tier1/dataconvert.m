function datanew=dataconvert(data1)
% Data scaling between [0,1].
% data1=dlmread('data1.txt');
 mini=min(min(data1));
 [n,m]=size(data1);
 data1=abs(mini)*ones(size(data1))+data1;
 maxi=max(max(data1));
 datanew=data1/maxi;
 