function out=distLR(x,y)
%Calculates distance of two LR type fuzzy triangular numbers given in form
% x=(l,x,r) and y=(l,y,r)
d=x(2)-y(2);
deltaL=x(1)-y(1);
deltaR=x(3)-y(3);
out=d^2+deltaL^2/6+deltaR^2/6+d*(deltaR-deltaL)/2;
