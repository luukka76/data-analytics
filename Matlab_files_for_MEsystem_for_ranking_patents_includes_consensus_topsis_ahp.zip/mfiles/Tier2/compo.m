function composite=compo(v,w)
%Calculating weighted linear combination.
%Input: priority vectors (v) and weight vector (v)
%Output: weighted linear combination: composite
composite=v*w';

