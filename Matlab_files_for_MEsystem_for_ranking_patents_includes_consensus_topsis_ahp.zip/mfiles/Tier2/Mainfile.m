clear all
close all
%loading the data(reciprocal matrixes):
dataDM

[n,m]=size(C1DM1);

%Geometric means of reciprocal matrixes over three decision makers:
for i=1:size(C1DM1,1)
    for j=1:size(C1DM1,1)
        x1=[C1DM1(i,j) C1DM2(i,j) C1DM3(i,j)];
        x2=[C2DM1(i,j) C2DM2(i,j) C2DM3(i,j)];
        x3=[C3DM1(i,j) C3DM2(i,j) C3DM3(i,j)];
        x4=[C4DM1(i,j) C4DM2(i,j) C4DM3(i,j)];
        x5=[C5DM1(i,j) C5DM2(i,j) C5DM3(i,j)];
        x6=[C6DM1(i,j) C6DM2(i,j) C6DM3(i,j)];
        C1(i,j)=geommean1(x1);
        C2(i,j)=geommean1(x2);
        C3(i,j)=geommean1(x3);
        C4(i,j)=geommean1(x4);
        C5(i,j)=geommean1(x5);
        C6(i,j)=geommean1(x6);
    end
end
%Calculating priority vectors, now using matlab's build in computations for
%eigenvalue and eigenvector and then normalizing priority vector.
[priorv1,lambda1]=priorityv(C1);
[priorv2,lambda2]=priorityv(C2);
[priorv3,lambda3]=priorityv(C3);
[priorv4,lambda4]=priorityv(C4);
[priorv5,lambda5]=priorityv(C5);
[priorv6,lambda6]=priorityv(C6);
disp('Priority vectors:')
v=[priorv1 priorv2 priorv3 priorv4 priorv5 priorv6]

%Calculating consistency index and consistency ratios:
[CI1,CR1]=consistencyI(lambda1,n);
[CI2,CR2]=consistencyI(lambda2,n);
[CI3,CR3]=consistencyI(lambda3,n);
[CI4,CR4]=consistencyI(lambda4,n);
[CI5,CR5]=consistencyI(lambda5,n);
[CI6,CR6]=consistencyI(lambda6,n);
disp('Consistency indexes:')
CI=[CI1,CI2,CI3,CI4,CI5,CI6]
disp('Consistency ratios:')
CR=[CR1,CR2,CR3,CR4,CR5,CR6]

%Calculating composite weight of the alternatives:
w=1/n*ones(1,m);    
%Calculate weighted linear combinations:
composite=compo(v,w)
%Sorts the linear combinations to descending order:
[Y,I]=sort(composite,'descend');
ranking=1:6;
patents=[2 7 8 11 16 18]';

disp('Ranking of patents:[rank patent]')
Order=[ranking' patents(I)]


