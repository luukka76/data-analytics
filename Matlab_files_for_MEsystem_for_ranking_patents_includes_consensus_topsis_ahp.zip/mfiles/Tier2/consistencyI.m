function [CI,CR]=consistencyI(lambda,n)
%Calculates consistency index and consistency ratio.
%Inputs: Eigenvalues (lambda) and length of the vector (n).
%Output: 
%CI:    Consistency index (CI=(lambda_max-n)/(n-1)
%CR:    Consistency ratio CR=CI/RI.
%
CI=(lambda-n)/(n-1);
% Random consistency indexes for sample size 500 for first 10 n:
RI=[0 0 0.58 0.9 1.12 1.24 1.32 1.41 1.45 1.49];
CR=CI/RI(n);