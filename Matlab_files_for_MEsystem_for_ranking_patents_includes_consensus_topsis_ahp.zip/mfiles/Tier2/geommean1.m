function gm=geommean(x)
[n,m]=size(x);
gm=(prod(x))^(1/m);