function [priorv,lambda]=priorityv(x)
%Calculates priority vector (priorv) and largest eigenvalue (lambda)
%Input:
%x:   reciprocal matrix
%Output: 
%priorv:    priority vector
%lambda:    largest eigenvalue
%
[w,lambda]=eig(x);
priorv=w(:,1)/sum(w(:,1));
lambda=lambda(1,1);
