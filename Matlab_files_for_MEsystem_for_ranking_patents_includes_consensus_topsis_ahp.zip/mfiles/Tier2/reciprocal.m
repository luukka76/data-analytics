function m=reciprocal(x)
%In the case we use some given data.
%Not used in these computations.
[n,m]=size(x);
for i=1:n
    for j=1:n
        m(i,j)=x(i)/x(j);
    end
end