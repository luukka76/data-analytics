Implementation of fuzzy similarity based fuzzy TOPSIS. Originally published in:

[1.] P. Luukka, Fuzzy Similarity in Multicriteria Decision-Making Problem Applied to Supplier Evaluation and Selection in
Supply Chain Management, Advances in Artificial Intelligence, 2011, 9 pages.
doi:10.1155/2011/353509

Later enhanced to cover four different similarities and applied with overall ranking to evaluate R&D projects as investements in:

[2.] M. Collan, P. Luukka, Evaluating R&D projects as investments by using an overall ranking from four new fuzzy similarity 
measure based TOPSIS variants, IEEE Transactions on Fuzzy Systems, 26,6, (2013), pp. 1-11. 
doi:http://dx.doi.org/10.1109/TFUZZ.2013.2260758

Important information which you need to give in order to apply the program: 

Main file is simply mainfile.m and main function call in it is

[CCS,Sstar,Order]=Stopsis(WD,FDM,k,m,n,ideal,criteria,simi);

Where for inputs:

WD: all importance weights
FDM: decision matrix
k: no of decision makers
n: number of criterias
ideal: which criteria you want to use to calculate FPIS and FNIS from three alternatives.
criteria: information whether criteria is benefit or cost criteria given as a vector.
simi: which similarity measure is chosen. Integer number, 4 possibilities coded.

for outputs:

CCS: closeness value when now similarity is used to calculate it.
Sstar: Similarities w.r.t. attribute and FPIS.
Sneg: Similarities w.r.t. attribute and NPIS.
Order: alternatives 

Below it is demonstrated in a form of an example.
When you place your own data following information needs to be given:

Number of decision makers k, i.e.
k=3;        
Number of criterias to be evaluated n i.e.
n=5;        
Information about is the given criteria cost or benefit criteria:
Benefit=1, Cost=2, should be given as a vector of length n. i.e.
criteria=[1 1 1 1 1];

%Chosen similarity measure: (See [2.] for more information about them)
simi=4;

Number of attributes to be ranked (suppliers in example case in the article). i.e.
m=5; 

Criteria for selecting Fuzzy Positive Ideal Solution FPIS and Fuzzy Negative Ideal Solution FNIS.
Three possible option are now implemented. See [1.] for more information. i.e.

ideal=1;     

Next we call file lingvar where the needed linguistic variables for importance weight of each criterion and for ratings as generalized fuzzy
numbers. See linvar.m for details.

lingvar

And of course importance weights and decision matrixes from each of the decision makers i.e.

Example of importance weights from three decision makers for five criterias:

WD1={H VH VH H H};
WD2={H VH VH H H};
WD3={H VH H H H};

These are combined into one:

WD={WD1;WD2;WD3};

For importance weights possible linguistic numbers implemented now are very low (VL), low, (L), medium low (ML),
medium  (M), medium high, (MH), high (H), very high (VH).

%Example of decision matrices from three decision makers:

FDM1={MG MG G G G; G VG VG G VG; VG VG VG VG G; G G MG G G; MG MG MG MG MG};
FDM2={MG MG G G G; G VG VG VG VG; VG G VG VG VG; G G MG G G; MG G MG MG MG};
FDM3={MG VG G G G; G VG VG VG VG; G G G VG G; G MG G G VG; MG G MG G MG};

which are combined into one:

FDM={FDM1;FDM2;FDM3};

For the ratings possible linguiestic numbers implemented now are Very Poor (VP), Poor (P), Medium Poor (MP), Fair (F), 
Medium Good (MG), Good (G), Very Good (VG).

After this we just call our main function Stopsis:

[CCS,Sstar,Order]=Stopsis(WD,FDM,k,m,n,ideal,criteria,simi);


Example 2:

In the second example we have four decision makers, six attributes (suppliers) to be ranked and four criterias. 
Criterias are now product quality, service quality, delivery time and price. Now price is a cost criteria and others benefit criterias.

Number of decision makers k, i.e.
k=4;        
Number of criterias to be evaluated n i.e.
n=4;        
Information about is the given criteria cost or benefit criteria:
Benefit=1, Cost=2, should be given as a vector of length n. i.e.
criteria=[1 1 1 2];

Number of attributes to be ranked (suppliers in example case). i.e.
m=6; 

Criteria for selecting Fuzzy Positive Ideal Solution FPIS and Fuzzy Negative Ideal Solution FNIS.
Three possible option are now implemented. See [1.] for more information. i.e.

ideal=3;     

simi=4;

WD1={VH H H H};
WD2={H VH VH H};
WD3={MH H H MH};
WD4={M M MH MH};
WD={WD1;WD2;WD3;WD4};

FDM1={G G G F; MG G MG G; F F G VG; F P G G; MG MP MG MG; G MP F G};
FDM2={MG G MG G; G MG G G; F F G VG; MG MP MG MG; F MP F MG; MG P F VG};
FDM3={G MG MG G; F MG G F; MG P F G; MG MP MG G; F MP F G; MG P MG VG};
FDM4={G MG G G; MG G G MG; G F MG G; F P G G; MG MP MG MG; MG MP F G};
FDM={FDM1;FDM2;FDM3;FDM4};

After this we just call our main function Stopsis:

[CCS,Sstar,Order]=Stopsis(WD,FDM,k,m,n,ideal,criteria,simi);

