READ ME file for Similarity classifier with OWA operators


Similarity classifier with OWA operators toolbox presents vector based classification method
which uses similarity measures and OWA operators to make a distiction to which class samples belong.
It creates ideal vectors for each class and then uses similarity to measure how similar the samples are
compared to each ideal vector. These similarity vectors are then aggregated by OWA operators.
For more information about the method see the original publication:

P. Luukka, O. Kurama, Similarity classifier with ordered weighted averaging operators,
Expert Systems With Applications, 40, (2013), pp. 995-1002

Usaged of the toolbox:

Mainfile to use is mainfile1.m where the main function call is:
[Mean_accuracy, Variance,p1,m1]=simclass2(data,v,c, measure, p, alpha, N,rn,pl)

Inputs:

 data: put your data file in matrix form, rows indicates samples and
 columns features of the data.
 v:   how many columns of features you are using i.e. v=[1:4] means you will
 use first four columns as features of your data.
 c: column where you class labels are. It should be in numerical form.
 measure: Which quantifier in OWA operators you want to use. 
 1=Basic RIM quantifier
 2=Quadratic quantifier
 3=Exponential quantifier
 4=Trigonometric quantifier
 5=O'Hagans method.
 p: parameter in generalized Lukasiewics similarity, can be studied as a range of
 parameter values and then given as a vector i.e. p=[0.1:0.1:5].
 alpha: Alpha value in owa operators. Can be given as vector i.e. alpha=[0.1:0.1:5].
 N: how many times data is divided randomly into testing set and learning set.
 rn: portion of data which is used in learning set. default rn=1/2 (data
 is divided in half; half is used in testing set and half in learning set.
 pl: do you want to plot how the parameter changes in p and alpha changes the
 mean classification accuracies and variances. 1=yes 0=No.

Outputs:

 Mean_accuracy: Mean classification accuracy for the testing set. 
 Variance: variances for the testing set.
 p1 and m1: best parameter values w.r.t. mean classification accuracy.
 p1 for p parameter and m1 for alpha.

In the case one do not want to use given crossvalidation scheme, but want to use your own there is also implemented
a version where you can specify yourself the testing set and learning set data files. Example from this is
given in example1.m and there main function call is:

[Classification_accuracy,p1,alpha1,classes]=simclass1(datalearn, datatest,v,c, measure, p, alpha,pl);

Inputs:

 datatest: put your test data file in matrix form, rows indicates samples and
 columns features of the data.
 datalearn: put your learning data file in matrix form, rows indicates samples and
 columns features of the data.
 v:   how many columns of features you are using i.e. v=[1:4] means you will
 use first four columns as features of your data.
 c: column where you class labels are. It should be in numerical form.
 measure: Which quantifier in OWA operators you want to use. 
 1=Basic RIM quantifier
 2=Quadratic quantifier
 3=Exponential quantifier
 4=Trigonometric quantifier
 5=O'Hagans method.
 p: parameter in generalized Lukasiewics similarity, can be studied as a range of
 parameter values and then given as a vector i.e. p=[0.1:0.1:5].
 alpha: Alpha value in owa operators. Can be given as vector i.e. alpha=[0.1:0.1:5].
pl: do you want to plot how the parameter changes in p and alpha changes the
 mean classification accuracies and variances.1=yes 0=No

OUTPUTS:

Classification_accuracy:classification accuracy for test set.
p1: p parameter value which was used for this classification accuracy
alpha1: alpha parameter value which was used for this classification accuracy
classes: Class information. To which class the sample was classified (in testing set data, datatest) 
